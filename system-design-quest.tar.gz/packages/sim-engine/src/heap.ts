/** Min-heap ordered by (time, seq). seq breaks ties so equal-time events run in insertion order. */
export class EventHeap<T> {
  private items: { t: number; seq: number; v: T }[] = [];
  private seq = 0;

  get size(): number {
    return this.items.length;
  }

  push(t: number, v: T): void {
    const item = { t, seq: this.seq++, v };
    const a = this.items;
    a.push(item);
    let i = a.length - 1;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (!this.less(a[i]!, a[p]!)) break;
      [a[i], a[p]] = [a[p]!, a[i]!];
      i = p;
    }
  }

  pop(): { t: number; v: T } | undefined {
    const a = this.items;
    if (a.length === 0) return undefined;
    const top = a[0]!;
    const last = a.pop()!;
    if (a.length > 0) {
      a[0] = last;
      let i = 0;
      for (;;) {
        const l = 2 * i + 1;
        const r = l + 1;
        let m = i;
        if (l < a.length && this.less(a[l]!, a[m]!)) m = l;
        if (r < a.length && this.less(a[r]!, a[m]!)) m = r;
        if (m === i) break;
        [a[i], a[m]] = [a[m]!, a[i]!];
        i = m;
      }
    }
    return { t: top.t, v: top.v };
  }

  private less(x: { t: number; seq: number }, y: { t: number; seq: number }): boolean {
    return x.t < y.t || (x.t === y.t && x.seq < y.seq);
  }
}
