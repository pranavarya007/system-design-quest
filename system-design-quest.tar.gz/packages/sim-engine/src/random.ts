import type { ServiceDist } from "./types.js";

/** Small, fast, seedable PRNG (mulberry32). Same seed, same sequence, on every platform. */
export function createRng(seed: number) {
  let a = seed >>> 0;
  const next = (): number => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  let spareNormal: number | null = null;

  const normal = (): number => {
    if (spareNormal !== null) {
      const s = spareNormal;
      spareNormal = null;
      return s;
    }
    let u = 0;
    while (u === 0) u = next();
    const v = next();
    const r = Math.sqrt(-2 * Math.log(u));
    spareNormal = r * Math.sin(2 * Math.PI * v);
    return r * Math.cos(2 * Math.PI * v);
  };

  const exponential = (mean: number): number => -Math.log(1 - next()) * mean;

  /** z-score of the 99th percentile of a standard normal. */
  const Z99 = 2.3263478740408408;

  const service = (d: ServiceDist): number => {
    let x: number;
    switch (d.dist) {
      case "deterministic":
        x = d.us;
        break;
      case "exponential":
        x = exponential(d.mean_us);
        break;
      case "lognormal": {
        const mu = Math.log(d.p50_us);
        const sigma = Math.log(d.p99_us / d.p50_us) / Z99;
        x = Math.exp(mu + sigma * normal());
        break;
      }
    }
    return Math.max(1, Math.round(x));
  };

  return { next, normal, exponential, service };
}

export type Rng = ReturnType<typeof createRng>;
