/** Prefix a site path with the configured base, so links work on a custom domain or under /repo-name/. */
export const href = (path: string): string => {
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  return `${base}${path.startsWith("/") ? path : `/${path}`}`;
};
