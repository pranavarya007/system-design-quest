# Course content licence

Copyright (c) 2026 Aimbytes and System Design Quest contributors.

The course content in this repository (lesson text, quizzes, case-study write-ups and images in `content/` and `apps/web/src/pages/learn/`) is licensed under the **Creative Commons Attribution 4.0 International** licence (CC BY 4.0).

You may copy, adapt and share it for any purpose, including commercially, as long as you give appropriate credit, link to the licence, and say if you made changes.

Suggested credit: *"Based on System Design Quest (https://github.com/aimbytes/system-design-quest), developed and maintained by Aimbytes, CC BY 4.0."*

Full legal text: https://creativecommons.org/licenses/by/4.0/legalcode

Code, including code blocks and YAML scenario files inside `content/`, is MIT licensed. See [LICENSING.md](LICENSING.md).

The Aimbytes name and logo are not covered by either licence.
