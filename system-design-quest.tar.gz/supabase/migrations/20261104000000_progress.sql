-- System Design Quest: progress, XP and sync.
-- Clients only ever insert events through ingest_events(). The server decides XP,
-- ignores event ids it has already seen, and keeps per-day rollups small for the free tier.

create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  handle text unique,
  avatar_url text,
  timezone text not null default 'UTC',
  weekly_goal int not null default 3 check (weekly_goal between 1 and 14),
  created_at timestamptz not null default now()
);

-- Must match packages/game/src/rules.ts
create table public.xp_rules (
  type text primary key,
  xp int not null check (xp >= 0)
);
insert into public.xp_rules (type, xp) values
  ('lesson_check', 20), ('lesson_check_perfect', 10), ('prediction_correct', 10), ('sim_goal', 30),
  ('boss_1_star', 150), ('boss_2_star', 250), ('boss_3_star', 400), ('defend', 100),
  ('classic_problem', 400), ('case_study', 300), ('review_card', 2),
  ('lesson_started', 0), ('prediction_wrong', 0);

create table public.events (
  id uuid primary key,                 -- UUIDv7 made on the client
  user_id uuid not null references auth.users (id) on delete cascade,
  type text not null references public.xp_rules (type),
  ref text not null check (length(ref) <= 200),
  payload jsonb not null default '{}'::jsonb check (pg_column_size(payload) <= 4096),
  xp int not null default 0,           -- set by the server, never by the client
  created_at timestamptz not null,
  received_at timestamptz not null default now()
);
create index events_user_type_ref on public.events (user_id, type, ref);
create index events_received on public.events (received_at);

-- One row per goal that earned XP, kept forever so pruning old events never re-awards XP.
create table public.xp_awards (
  user_id uuid not null references auth.users (id) on delete cascade,
  type text not null,
  ref text not null,
  awarded_at timestamptz not null default now(),
  primary key (user_id, type, ref)
);

create table public.xp_daily (
  user_id uuid not null references auth.users (id) on delete cascade,
  day date not null,
  xp int not null default 0,
  sessions int not null default 0,
  primary key (user_id, day)
);

create table public.lesson_progress (
  user_id uuid not null references auth.users (id) on delete cascade,
  lesson_slug text not null,
  status text not null default 'started' check (status in ('started', 'completed')),
  best_score int not null default 0,
  attempts int not null default 0,
  completed_at timestamptz,
  primary key (user_id, lesson_slug)
);

create table public.boss_attempts (
  id uuid primary key,
  user_id uuid not null references auth.users (id) on delete cascade,
  boss_slug text not null,
  design jsonb not null,
  seed int not null,
  engine_version text not null,
  scenario_hash text not null,
  stars int not null check (stars between 0 and 3),
  defend_text text check (length(defend_text) <= 4000),
  defend_score int,
  created_at timestamptz not null default now()
);

create table public.badges_earned (
  user_id uuid not null references auth.users (id) on delete cascade,
  badge_slug text not null,
  earned_at timestamptz not null default now(),
  primary key (user_id, badge_slug)
);

create table public.review_cards (
  user_id uuid not null references auth.users (id) on delete cascade,
  question_id text not null,
  due_at timestamptz not null,
  interval_days int not null default 1,
  ease real not null default 2.5,
  primary key (user_id, question_id)
);

-- Row-level security: every user sees and edits only their own rows.
alter table public.profiles enable row level security;
alter table public.events enable row level security;
alter table public.xp_daily enable row level security;
alter table public.xp_awards enable row level security;
alter table public.lesson_progress enable row level security;
alter table public.boss_attempts enable row level security;
alter table public.badges_earned enable row level security;
alter table public.review_cards enable row level security;
alter table public.xp_rules enable row level security;

create policy "read xp rules" on public.xp_rules for select using (true);
create policy "own profile" on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "read own events" on public.events for select using (auth.uid() = user_id);
create policy "read own xp" on public.xp_daily for select using (auth.uid() = user_id);
create policy "read own progress" on public.lesson_progress for select using (auth.uid() = user_id);
create policy "read own attempts" on public.boss_attempts for select using (auth.uid() = user_id);
create policy "read own badges" on public.badges_earned for select using (auth.uid() = user_id);
create policy "own review cards" on public.review_cards for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
-- No insert/update policies on events, xp_daily, lesson_progress or badges: writes go through ingest_events only.

create or replace function public.ingest_events(events jsonb)
returns int
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  e jsonb;
  inserted int := 0;
  rule_xp int;
  award int;
  tz text;
  ev_time timestamptz;
begin
  if uid is null then
    raise exception 'not signed in';
  end if;
  if jsonb_array_length(events) > 500 then
    raise exception 'batch too large (max 500 events)';
  end if;

  insert into profiles (id) values (uid) on conflict (id) do nothing;
  select timezone into tz from profiles where id = uid;

  for e in select * from jsonb_array_elements(events) loop
    select xp into rule_xp from xp_rules where type = e->>'type';
    if rule_xp is null then
      continue; -- unknown event type: ignore rather than fail the batch
    end if;

    -- Client clocks are not trusted beyond this: clamp to [now - 30 days, now].
    ev_time := least(now(), greatest(now() - interval '30 days', (e->>'created_at')::timestamptz));

    -- XP for a given goal counts once per user, however often it is repeated.
    award := case when rule_xp > 0 and not exists (
      select 1 from xp_awards a where a.user_id = uid and a.type = e->>'type' and a.ref = e->>'ref'
    ) then rule_xp else 0 end;

    insert into events (id, user_id, type, ref, payload, xp, created_at)
    values ((e->>'id')::uuid, uid, e->>'type', e->>'ref', coalesce(e->'payload', '{}'::jsonb), award, ev_time)
    on conflict (id) do nothing;

    if found then
      inserted := inserted + 1;
      if award > 0 then
        insert into xp_awards (user_id, type, ref) values (uid, e->>'type', e->>'ref') on conflict do nothing;
      end if;
      insert into xp_daily (user_id, day, xp, sessions)
      values (uid, (ev_time at time zone tz)::date, award, 1)
      on conflict (user_id, day) do update set xp = xp_daily.xp + excluded.xp;

      if e->>'type' = 'lesson_started' then
        insert into lesson_progress (user_id, lesson_slug, attempts) values (uid, e->>'ref', 1)
        on conflict (user_id, lesson_slug) do update set attempts = lesson_progress.attempts + 1;
      elsif e->>'type' in ('sim_goal', 'lesson_check', 'lesson_check_perfect') then
        insert into lesson_progress (user_id, lesson_slug, status, best_score, completed_at)
        values (uid, e->>'ref', 'completed', coalesce((e->'payload'->>'score')::int, 0), ev_time)
        on conflict (user_id, lesson_slug) do update
          set status = 'completed',
              best_score = greatest(lesson_progress.best_score, excluded.best_score), -- only moves forward
              completed_at = coalesce(lesson_progress.completed_at, excluded.completed_at);
      end if;
    end if;
  end loop;
  return inserted;
end;
$$;

revoke all on function public.ingest_events(jsonb) from public;
grant execute on function public.ingest_events(jsonb) to authenticated;

-- Totals for the signed-in user, derived from events (never stored by the client).
create or replace view public.my_totals
with (security_invoker = true) as
select
  user_id,
  sum(xp)::int as xp,
  count(*) filter (where day >= (now() at time zone 'UTC')::date - 6)::int as active_days_this_week
from xp_daily
group by user_id;

-- Free-tier housekeeping: raw events older than 90 days are pruned (rollups stay).
-- Schedule with pg_cron if enabled:  select cron.schedule('prune-events', '0 3 * * *', $$select public.prune_events()$$);
create or replace function public.prune_events()
returns void
language sql
security definer
set search_path = public
as $$
  delete from events where received_at < now() - interval '90 days';
$$;
revoke all on function public.prune_events() from public;
