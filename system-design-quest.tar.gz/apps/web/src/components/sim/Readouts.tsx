import type { SimResult } from "@sdq/sim-engine";

export function windowAt(result: SimResult, t: number) {
  const i = Math.min(result.windows.length - 1, Math.max(0, Math.floor(t / 1_000_000) - 1));
  return result.windows[i]!;
}

export const fmtMs = (us: number | null) =>
  us === null ? "–" : us >= 1_000_000 ? `${(us / 1_000_000).toFixed(1)} s` : `${Math.round(us / 1000)} ms`;

export function Readouts({ result, t, goalP99Ms, server }: { result: SimResult; t: number; goalP99Ms?: number; server: string }) {
  const w = windowAt(result, t);
  const p99 = w.p99_us;
  const p99Bad = goalP99Ms !== undefined && p99 !== null && p99 / 1000 > goalP99Ms;
  const util = Math.round((w.utilisation[server] ?? 0) * 100);
  return (
    <div className="readouts" aria-live="off">
      <div className={`readout ${p99Bad ? "bad" : ""}`}>
        <div className="readout-value">{fmtMs(p99)}</div>
        <div className="readout-label">p99 latency, last second</div>
      </div>
      <div className={`readout ${w.errors > 0 ? "bad" : ""}`}>
        <div className="readout-value">{w.errors}</div>
        <div className="readout-label">failed requests, last second</div>
      </div>
      <div className={`readout ${util >= 95 ? "warn" : ""}`}>
        <div className="readout-value">{util}%</div>
        <div className="readout-label">server 1 busy</div>
      </div>
    </div>
  );
}
