export type Status = "open" | "beta" | "planned";

export interface Lesson {
  title: string;
  path?: string;
}

export interface Module {
  n: number;
  title: string;
  status: Status;
  summary: string;
  lessons?: Lesson[];
  problems?: string[];
}

export interface Act {
  title: string;
  modules: Module[];
}

export const COURSE: Act[] = [
  {
    title: "Foundations",
    modules: [
      { n: 0, title: "Orientation", status: "planned", summary: "Play a simulation in the first minute, then take the placement quiz." },
      { n: 1, title: "How the internet works", status: "planned", summary: "Client-server, TCP and UDP, DNS, HTTP versions, TLS, WebSockets." },
      {
        n: 2,
        title: "Numbers, estimation and queueing",
        status: "beta",
        summary: "Latency numbers, back-of-envelope maths, Little's Law, and why latency climbs past 70% busy.",
      },
      { n: 3, title: "Core principles", status: "planned", summary: "Scalability, availability, CAP as a choice made during a partition, PACELC." },
    ],
  },
  {
    title: "Building blocks",
    modules: [
      {
        n: 4,
        title: "Networking components",
        status: "beta",
        summary: "Load balancers, proxies, API gateways, CDNs and service discovery.",
        lessons: [{ title: "Kill a server behind the load balancer", path: "/learn/load-balancing/kill-a-server/" }],
        problems: ["URL shortener", "Rate limiter"],
      },
      { n: 5, title: "Storage and databases", status: "planned", summary: "Indexes, replication, sharding and hot partitions.", problems: ["Chat system"] },
      { n: 6, title: "Caching", status: "beta", summary: "Cache patterns, eviction, invalidation and stampedes.", problems: ["News feed"] },
      { n: 7, title: "Asynchronous processing", status: "beta", summary: "Queues, streams, delivery guarantees and backpressure.", problems: ["Notification system"] },
    ],
  },
  {
    title: "Distributed systems",
    modules: [
      { n: 8, title: "Distributed systems theory", status: "planned", summary: "Clocks, Raft, quorums, sagas, consistent hashing.", problems: ["Unique ID generator", "Key-value store"] },
      { n: 9, title: "Architecture and resilience", status: "planned", summary: "Timeouts, retries, circuit breakers, load shedding, cells.", problems: ["Payment system", "Ticket booking"] },
    ],
  },
  {
    title: "Production",
    modules: [
      { n: 10, title: "Reliability and operations", status: "planned", summary: "Observability, incidents, chaos, disaster recovery." },
      { n: 11, title: "Security", status: "planned", summary: "Auth, OAuth, encryption, DDoS and zero trust." },
      { n: 12, title: "Data at scale", status: "planned", summary: "Batch and stream processing, warehouses, search, ML basics." },
    ],
  },
  {
    title: "Mastery",
    modules: [
      { n: 13, title: "Interview mastery", status: "planned", summary: "Seven more classic problems and 45-minute mock interviews." },
      { n: 14, title: "Case studies and scenario bosses", status: "planned", summary: "12 sourced architectures and 6 scenarios inspired by public talks." },
    ],
  },
];

export const STATUS_LABEL: Record<Status, string> = {
  open: "Open",
  beta: "In the beta",
  planned: "Planned",
};
