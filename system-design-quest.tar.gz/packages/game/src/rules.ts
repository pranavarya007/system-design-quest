/**
 * XP and level rules. The server applies the same table in its trigger, so the number a learner
 * sees locally matches what sync records. Change both together (supabase/migrations).
 */
export const XP = {
  lesson_check: 20,
  lesson_check_perfect: 10,
  prediction_correct: 10,
  sim_goal: 30,
  boss_1_star: 150,
  boss_2_star: 250,
  boss_3_star: 400,
  defend: 100,
  classic_problem: 400,
  case_study: 300,
  review_card: 2,
} as const;

export type EventType = keyof typeof XP | "lesson_started" | "prediction_wrong";

export const xpFor = (type: EventType): number => (type in XP ? XP[type as keyof typeof XP] : 0);

/** Levels need XP and specific bosses, so quizzes alone can't reach the top titles. */
export const LEVELS = [
  { title: "Intern", xp: 0, bosses: [] },
  { title: "Junior Dev", xp: 300, bosses: [] },
  { title: "Developer", xp: 1_000, bosses: ["numbers"] },
  { title: "Senior Dev", xp: 2_500, bosses: ["networking", "caching"] },
  { title: "Tech Lead", xp: 5_000, bosses: ["storage", "async"] },
  { title: "Staff Engineer", xp: 8_000, bosses: ["distributed"] },
  { title: "Principal", xp: 12_000, bosses: ["patterns", "reliability"] },
  { title: "Distinguished", xp: 16_000, bosses: ["security", "data"] },
  { title: "Fellow", xp: 20_000, bosses: [] },
  { title: "Architect", xp: 25_000, bosses: ["mock-interview"] },
] as const;

export function levelFor(xp: number, bossesWon: ReadonlySet<string>) {
  let current: (typeof LEVELS)[number] = LEVELS[0];
  for (const l of LEVELS) {
    if (xp >= l.xp && l.bosses.every((b) => bossesWon.has(b))) current = l;
    else break;
  }
  return current;
}

export const WEEKLY_GOAL_DEFAULT = 3;
