/** Change these once the GitHub repo and domain exist. */
export const SITE = {
  name: "System Design Quest",
  repo: "https://github.com/aimbytes/system-design-quest",
  maintainer: { name: "Aimbytes", url: "https://www.aimbytes.com/" },
} as const;
