import { z } from "zod";

/** "250ms", "20s", "2m", or a bare number of seconds. */
export const Duration = z
  .union([z.number().nonnegative(), z.string().regex(/^\d+(\.\d+)?(us|ms|s|m)$/, 'Use a duration like "500ms", "20s" or "2m"')])
  .transform((v) => {
    if (typeof v === "number") return Math.round(v * 1_000_000);
    const m = /^(\d+(?:\.\d+)?)(us|ms|s|m)$/.exec(v)!;
    const n = Number(m[1]);
    const unit = { us: 1, ms: 1_000, s: 1_000_000, m: 60_000_000 }[m[2] as "us" | "ms" | "s" | "m"];
    return Math.round(n * unit);
  });

const Id = z.string().regex(/^[a-z][a-z0-9_-]*$/, "Ids are lowercase letters, digits, - and _");

const ServiceMs = z.union([
  z.object({ p50: z.number().positive(), p99: z.number().positive() }).refine((s) => s.p99 >= s.p50, "p99 must be at least p50"),
  z.object({ mean: z.number().positive() }),
  z.object({ fixed: z.number().positive() }),
]);

const LbNode = z.object({
  id: Id,
  kind: z.literal("lb"),
  algo: z.enum(["round_robin", "least_connections", "random"]).default("round_robin"),
  health_check: Duration.optional(),
  label: z.string().optional(),
}).strict();

const ServerNode = z.object({
  id: Id,
  kind: z.literal("server"),
  workers: z.number().int().min(1).max(256),
  queue: z.union([z.number().int().min(0), z.literal("unbounded")]).default(100),
  service_ms: ServiceMs,
  label: z.string().optional(),
}).strict();

const Node = z.discriminatedUnion("kind", [LbNode, ServerNode]);

const Choice = z.object({ id: z.string(), text: z.string() }).strict();

export const ScenarioSchema = z
  .object({
    schema: z.literal(1),
    title: z.string(),
    seed: z.number().int().default(1),
    duration: Duration,
    nodes: z.array(Node).min(1),
    edges: z.array(z.tuple([Id, Id])).default([]),
    traffic: z.object({
      rps: z.array(z.tuple([Duration, z.number().nonnegative()])).min(1),
      /** Reserved for caching and sharding scenarios (key skew). Not used by the engine yet. */
      keys: z.string().optional(),
    }),
    client: z
      .object({
        timeout: Duration.optional(),
        retries: z.number().int().min(0).max(10).default(0),
        backoff: Duration.optional(),
        jitter: z.boolean().default(false),
      })
      .default({}),
    events: z
      .array(z.object({ at: Duration, kill: Id.optional(), revive: Id.optional() }).strict().refine((e) => e.kill || e.revive, "An event needs kill or revive"))
      .default([]),
    controls: z
      .array(
        z.object({
          node: Id,
          param: z.enum(["workers", "rps", "algo"]),
          range: z.tuple([z.number(), z.number()]).optional(),
          label: z.string().optional(),
        }),
      )
      .default([]),
    predict: z
      .object({
        ask: z.string(),
        options: z.array(Choice).min(2),
        answer: z.string(),
        explain: z.string(),
      })
      .refine((p) => p.options.some((o) => o.id === p.answer), "predict.answer must match an option id")
      .optional(),
    goal: z
      .object({
        p99_ms: z.number().positive().optional(),
        error_rate: z.number().min(0).max(1).optional(),
      })
      .optional(),
    /** Required: what this model leaves out, shown to every learner. */
    ignores: z.string().min(10),
    narrate: z.array(z.object({ at: Duration, text: z.string() }).strict()).default([]),
  })
  .superRefine((s, ctx) => {
    const ids = new Set(s.nodes.map((n) => n.id));
    if (ids.size !== s.nodes.length) ctx.addIssue({ code: "custom", message: "Node ids must be unique", path: ["nodes"] });
    s.edges.forEach(([a, b], i) => {
      if (!ids.has(a) || !ids.has(b)) ctx.addIssue({ code: "custom", message: `Edge ${a} -> ${b} names an unknown node`, path: ["edges", i] });
    });
    s.events.forEach((e, i) => {
      const n = e.kill ?? e.revive;
      if (n && !ids.has(n)) ctx.addIssue({ code: "custom", message: `Event names unknown node ${n}`, path: ["events", i] });
    });
  });

export type Scenario = z.output<typeof ScenarioSchema>;
