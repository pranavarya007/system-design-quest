# Contributing

Thank you for helping. You don't need to know React: lessons are MDX and simulations are YAML.

## Set up

```bash
pnpm install
pnpm dev
```

Or open the repo in GitHub Codespaces; the dev container installs everything.

## Pick a path

| Path | Do this | Reviewed by |
| --- | --- | --- |
| Fix | Edit one file. Typos, wrong numbers, broken links. | 1 maintainer or steward |
| Write a scenario | Add `content/scenarios/<name>.yaml`. Run `pnpm validate:content`. | Sim-correctness group |
| Write a lesson | Copy `docs/templates/lesson.mdx` into `apps/web/src/pages/learn/<module>/`. | 1 maintainer + the module's steward |
| Build a component | Pick up an issue labelled `viz-request`. Include a reduced-motion version. | Builder group |
| Write a case study | Claim one from the backlog issue. Every claim links to a source in `sources.yaml`. | Its steward + 1 maintainer |

Good first issues are labelled `good first issue`.

## Scenario rules

- Every scenario has an `ignores:` note saying what the model leaves out.
- Quote any text that contains a comma inside `{ }`. The schema rejects unknown keys, so a stray comma fails validation instead of silently cutting your text.
- If you write a `predict.explain`, run the scenario and check the numbers say what your explanation claims. Add a test in `packages/schema/test/` for anything a lesson relies on.
- Don't tune a scenario so that one design wins only on its seed. Goals should hold on other seeds too.

## Writing style

- Plain words, short sentences, active voice.
- Specific numbers with units ("about 150 requests a second", not "a lot").
- No invented stories presented as real events. Say "picture a service..." or cite a source.

## Checks on every pull request

Schema validation, engine and schema tests, a full build and a bundle-size check run on every pull request. Preview deploys are posted once Cloudflare Pages is connected to the repo.

## Sign-off

Every commit needs `git commit -s` (DCO). See [LICENSING.md](LICENSING.md).

## Conduct

Be kind and assume good intent. We follow the [Contributor Covenant 2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct/). Report problems to the maintainers through [Aimbytes](https://www.aimbytes.com/).
