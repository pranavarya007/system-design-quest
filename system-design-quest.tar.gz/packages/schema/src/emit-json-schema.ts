/** Writes content/scenarios/scenario.schema.json so editors autocomplete scenario YAML. */
import { writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { zodToJsonSchema } from "zod-to-json-schema";
import { ScenarioSchema } from "./scenario.js";

const out = resolve(import.meta.dirname, "../../../content/scenarios/scenario.schema.json");
const schema = zodToJsonSchema(ScenarioSchema, { name: "Scenario", $refStrategy: "none", pipeStrategy: "input" });
writeFileSync(out, JSON.stringify(schema, null, 2) + "\n");
console.log(`wrote ${out}`);
