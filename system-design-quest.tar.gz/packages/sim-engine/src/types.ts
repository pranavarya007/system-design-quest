/** All times are integer microseconds. */
export type Micros = number;

export type ServiceDist =
  | { dist: "exponential"; mean_us: Micros }
  | { dist: "lognormal"; p50_us: Micros; p99_us: Micros }
  | { dist: "deterministic"; us: Micros };

export interface LbSpec {
  id: string;
  kind: "lb";
  algo: "round_robin" | "least_connections" | "random";
  /** How long the load balancer takes to notice a backend went down or came back. */
  health_check_us?: Micros;
}

export interface ServerSpec {
  id: string;
  kind: "server";
  workers: number;
  /** Maximum waiting requests. Infinity = unbounded. */
  queue: number;
  service: ServiceDist;
}

export type NodeSpec = LbSpec | ServerSpec;

export interface ClientSpec {
  /** Client gives up on an attempt after this long. Undefined = waits forever. */
  timeout_us?: Micros;
  /** Extra attempts after the first one fails or times out. */
  retries?: number;
  /** Base delay before a retry; doubles on each retry. */
  backoff_us?: Micros;
  /** Randomise backoff (full jitter). */
  jitter?: boolean;
}

export interface ChaosEvent {
  at_us: Micros;
  kill?: string;
  revive?: string;
}

export interface SimConfig {
  seed: number;
  duration_us: Micros;
  nodes: NodeSpec[];
  edges: [string, string][];
  /** Node that receives client traffic. Defaults to the first load balancer, else the first node. */
  entry?: string;
  /** Piecewise-constant Poisson arrival rate: [start time, requests per second]. */
  traffic: [Micros, number][];
  client?: ClientSpec;
  events?: ChaosEvent[];
  /** Metrics window size. Default 1 second. */
  window_us?: Micros;
}

export type Outcome = "ok" | "rejected" | "failed" | "timeout";

/** One attempt of one request, enough for a renderer to animate it. */
export interface AttemptRecord {
  req: number;
  attempt: number;
  /** When the client sent this attempt. */
  sent_us: Micros;
  server: string | null;
  /** When a worker began serving it (undefined if it never started). */
  start_us?: Micros;
  /** When the client learned the outcome. */
  end_us: Micros;
  outcome: Outcome;
}

export interface RequestRecord {
  id: number;
  arrived_us: Micros;
  end_us: Micros;
  attempts: number;
  outcome: Outcome;
}

export interface NodeEvent {
  at_us: Micros;
  node: string;
  type: "down" | "up" | "lb_marked_down" | "lb_marked_up";
}

export interface Window {
  start_us: Micros;
  offered: number;
  ok: number;
  errors: number;
  attempts: number;
  p50_us: number | null;
  p99_us: number | null;
  /** Per server: fraction of worker time spent serving, 0..1. */
  utilisation: Record<string, number>;
  /** Per server: waiting + in-service requests, sampled at the end of the window. */
  in_system: Record<string, number>;
}

export interface Summary {
  requests: number;
  ok: number;
  errors: number;
  error_rate: number;
  mean_us: number | null;
  p50_us: number | null;
  p99_us: number | null;
  attempts: number;
  /** Requests completed per second over the whole run. */
  throughput_rps: number;
}

export interface SimResult {
  engine_version: string;
  config: SimConfig;
  requests: RequestRecord[];
  attempts: AttemptRecord[];
  node_events: NodeEvent[];
  windows: Window[];
  summary: Summary;
}
