import Dexie, { type Table } from "dexie";
import { uuidv7 } from "./uuidv7.js";
import { xpFor, type EventType } from "./rules.js";

export interface LocalEvent {
  /** UUIDv7 made here. The server ignores ids it has already seen, so uploads can be retried safely. */
  id: string;
  type: EventType;
  /** What the event is about: a lesson, scenario or boss slug. */
  ref: string;
  payload?: Record<string, unknown>;
  created_at: number;
  synced: 0 | 1;
}

class ProgressDb extends Dexie {
  events!: Table<LocalEvent, string>;
  constructor() {
    super("sdq-progress");
    this.version(1).stores({ events: "id, type, ref, synced, created_at" });
  }
}

let db: ProgressDb | null = null;
const getDb = (): ProgressDb | null => {
  if (typeof indexedDB === "undefined") return null;
  try {
    db ??= new ProgressDb();
    return db;
  } catch {
    return null;
  }
};

const listeners = new Set<() => void>();
export const onProgressChange = (fn: () => void) => {
  listeners.add(fn);
  return () => listeners.delete(fn);
};

/** Record one learning event on this device. Never throws: progress is best-effort in private windows. */
export async function recordEvent(type: EventType, ref: string, payload?: Record<string, unknown>): Promise<void> {
  const d = getDb();
  if (!d) return;
  try {
    await d.events.put({ id: uuidv7(), type, ref, payload, created_at: Date.now(), synced: 0 });
    listeners.forEach((fn) => fn());
  } catch {
    /* storage unavailable */
  }
}

/** XP shown on this device. Repeating the same goal for the same ref only counts once. */
export async function localXp(): Promise<number> {
  const d = getDb();
  if (!d) return 0;
  try {
    const all = await d.events.toArray();
    const seen = new Set<string>();
    let xp = 0;
    for (const e of all) {
      const key = `${e.type}:${e.ref}`;
      if (seen.has(key)) continue;
      seen.add(key);
      xp += xpFor(e.type);
    }
    return xp;
  } catch {
    return 0;
  }
}

export async function hasEvent(type: EventType, ref: string): Promise<boolean> {
  const d = getDb();
  if (!d) return false;
  try {
    return (await d.events.where({ type, ref }).count()) > 0;
  } catch {
    return false;
  }
}

/** Events waiting to upload. */
export async function unsynced(limit = 200): Promise<LocalEvent[]> {
  const d = getDb();
  if (!d) return [];
  return d.events.where("synced").equals(0).limit(limit).toArray();
}

export async function markSynced(ids: string[]): Promise<void> {
  const d = getDb();
  if (!d || ids.length === 0) return;
  await d.events.where("id").anyOf(ids).modify({ synced: 1 });
}
