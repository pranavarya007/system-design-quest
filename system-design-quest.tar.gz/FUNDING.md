# Funding

System Design Quest is free and will stay free. It is developed and maintained by [Aimbytes](https://www.aimbytes.com/).

## Our pledge

1. Nothing free will ever become paid: no lesson, scenario, boss fight or case study.
2. If we ever offer a paid service, it will charge only for things that cost money to run, such as AI grading or cohort dashboards for bootcamps. The code behind it stays open.
3. Money received and spent is shown publicly.

## How to support

- GitHub Sponsors (link to be added when the organisation is set up)
- Open Collective, hosted by Open Source Collective (to be set up)

Sponsorship pays for hosting beyond the free tiers, illustration, accessibility audits and paid reviews of new scenarios.
