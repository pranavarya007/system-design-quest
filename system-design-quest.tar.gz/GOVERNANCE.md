# Governance

System Design Quest is developed and maintained by [Aimbytes](https://www.aimbytes.com/), with decisions made in the open on GitHub.

## Roles

| Role | Can | How you get there |
| --- | --- | --- |
| Contributor | Open issues and pull requests | Anyone |
| Reviewer | Approve pull requests in one area | 3 merged contributions in that area, nominated by a steward |
| Module steward | Own a module or case study: review, keep facts current, triage its issues | Sustained reviewing, agreed by maintainers |
| Maintainer | Merge anywhere, cut releases, change governance | Long-term stewards, agreed by existing maintainers |

Stewards and maintainers are listed in [`.github/CODEOWNERS`](.github/CODEOWNERS).

## Reviews

- Fixes: 1 approval from a maintainer or the area's steward.
- New lessons: 1 maintainer and 1 module steward.
- Scenarios: 1 member of the sim-correctness group (owns `content/scenarios/**`).
- Engine changes: 1 maintainer; the queueing-theory tests must pass unchanged or with an explanation.

## Decisions

Small changes are decided in the pull request. Larger ones (new modules, licence or funding changes, breaking schema changes) get an issue labelled `rfc`, open for at least 7 days. Maintainers decide by consensus; if that fails, Aimbytes makes the final call and writes down why.

## Commitments

- Nothing free will ever become paid.
- Any future paid service charges only for things that cost money to run (for example AI grading), and its code stays open.
- Money received and spent is shown publicly. See [FUNDING.md](FUNDING.md).
