import type { SimResult } from "@sdq/sim-engine";

interface Props {
  result: SimResult;
  t: number;
  goalP99Ms?: number;
  onSeek?: (us: number) => void;
}

/** p99 latency per second (line) and errors per second (bars), drawn up to the current time. */
export function Timeline({ result, t, goalP99Ms, onSeek }: Props) {
  const W = 640;
  const H = 120;
  const padL = 44;
  const padR = 12;
  const top = 14;
  const base = 92;
  const windows = result.windows;
  const n = windows.length;
  const shown = Math.min(n, Math.floor(t / 1_000_000));
  const maxP99 = Math.max(goalP99Ms ?? 0, 200, ...windows.map((w) => (w.p99_us ?? 0) / 1000));
  const yMax = Math.ceil(maxP99 / 100) * 100;
  const maxErr = Math.max(1, ...windows.map((w) => w.errors));
  const x = (i: number) => padL + (i / Math.max(1, n - 1)) * (W - padL - padR);
  const y = (ms: number) => base - (ms / yMax) * (base - top);
  let path = "";
  for (let i = 0; i < shown; i++) {
    const p = windows[i]!.p99_us;
    if (p === null) continue;
    path += `${path ? "L" : "M"}${x(i).toFixed(1)} ${y(p / 1000).toFixed(1)}`;
  }
  const ticks = [0, yMax / 2, yMax];
  const secTicks = Array.from({ length: Math.floor((n - 1) / 10) + 1 }, (_, k) => k * 10);

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      role="img"
      aria-label="p99 latency and errors over time"
      style={{ display: "block", width: "100%", height: "auto", cursor: onSeek ? "pointer" : undefined }}
      onClick={(e) => {
        if (!onSeek) return;
        const r = (e.currentTarget as SVGSVGElement).getBoundingClientRect();
        const fx = ((e.clientX - r.left) / r.width) * W;
        const i = Math.round(((fx - padL) / (W - padL - padR)) * (n - 1));
        onSeek(Math.max(0, Math.min(n, i + 1)) * 1_000_000);
      }}
    >
      {ticks.map((v) => (
        <g key={v}>
          <line x1={padL} x2={W - padR} y1={y(v)} y2={y(v)} stroke="var(--grid)" />
          <text x={padL - 6} y={y(v) + 4} textAnchor="end" fontSize="10.5" fill="var(--ink-3)" className="num">
            {v >= 1000 ? `${(v / 1000).toFixed(1)}s` : `${v}ms`}
          </text>
        </g>
      ))}
      {goalP99Ms !== undefined && (
        <g>
          <line x1={padL} x2={W - padR} y1={y(goalP99Ms)} y2={y(goalP99Ms)} stroke="var(--mint)" strokeDasharray="4 4" />
          <text x={W - padR} y={y(goalP99Ms) - 4} textAnchor="end" fontSize="10.5" fill="var(--mint)">
            goal {goalP99Ms} ms
          </text>
        </g>
      )}
      {windows.slice(0, shown).map((w, i) =>
        w.errors > 0 ? (
          <rect key={i} x={x(i) - 3} y={base + 4} width="6" height={(w.errors / maxErr) * 18} fill="var(--red)" />
        ) : null,
      )}
      <path d={path} fill="none" stroke="var(--cobalt)" strokeWidth="2" strokeLinejoin="round" />
      <line x1={x(Math.max(0, shown - 1))} x2={x(Math.max(0, shown - 1))} y1={top} y2={base + 22} stroke="var(--ink-3)" strokeWidth="1" />
      {secTicks.map((s) => (
        <text key={s} x={x(s)} y={H - 2} textAnchor="middle" fontSize="10.5" fill="var(--ink-3)" className="num">
          {s}s
        </text>
      ))}
      <text x={padL} y={top - 3} fontSize="10.5" fill="var(--ink-2)">
        p99 latency
      </text>
      <text x={padL + 80} y={top - 3} fontSize="10.5" fill="var(--red)">
        errors
      </text>
    </svg>
  );
}
