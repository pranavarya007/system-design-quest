<h1>System Design Quest</h1>

<p><strong>Design it. Defend it. Watch it break.</strong></p>

<p>A free, open-source system design course where every concept runs in a real simulator. Build a design, predict what happens, then send traffic through it.</p>

<p>
  <a href="https://www.aimbytes.com/">
    <img src="docs/assets/aimbytes-mark.png" width="28" height="28" alt="" align="absmiddle">
  </a>
  Developed and maintained by <a href="https://www.aimbytes.com/"><strong>Aimbytes</strong></a>
</p>

---

## What's here

This repo is the first slice of the Interview Track beta: the engine, the scenario format, the website shell and one complete lesson.

| Part | Where | What it does |
| --- | --- | --- |
| Simulation engine | `packages/sim-engine` | Deterministic discrete-event simulator. Checked in CI against M/M/1, Erlang C (M/M/c) and Little's law. |
| Scenario schema | `packages/schema` | Zod schema for YAML scenarios, with readable errors and a JSON Schema for editor autocomplete. |
| Game rules | `packages/game` | XP table, levels, weekly goals, and local-first progress with an idempotent sync outbox. |
| Website | `apps/web` | Astro + React islands. Landing page, course map, and the lesson *Kill a server behind the load balancer*. |
| Content | `content/scenarios` | Every simulation is a YAML file. Start with `lb-kill.yaml`. |
| Database | `supabase/migrations` | Tables, row-level security, and the `ingest_events` function that dedupes events and sets XP. |

The full plan (curriculum, case studies, gamification, roadmap) lives in the project's planning doc.

## Run it

Requires Node 20+ and pnpm 10.

```bash
pnpm install
pnpm dev                 # http://localhost:4321
pnpm test                # engine, schema and game tests
pnpm validate:content    # validate and run every scenario
pnpm build               # static site in apps/web/dist
```

Sign-in is optional. Without Supabase keys the site runs in guest mode and saves progress on the device. To turn on GitHub sign-in, copy `apps/web/.env.example` to `apps/web/.env`, fill in your Supabase URL and anon key, and apply `supabase/migrations`.

## Write a scenario

```yaml
# content/scenarios/my-scenario.yaml
# yaml-language-server: $schema=./scenario.schema.json
schema: 1
title: My scenario
duration: 30s
nodes:
  - { id: lb, kind: lb, algo: least_connections }
  - { id: s1, kind: server, workers: 4, queue: 50, service_ms: { p50: 20, p99: 120 } }
edges: [[lb, s1]]
traffic: { rps: [[0s, 100], [15s, 300]] }
ignores: What this model leaves out, in plain words.
```

Then use it in any lesson: `<ClusterSim scenario="my-scenario" />`. See [CONTRIBUTING.md](CONTRIBUTING.md).

## Deploy

Pushes to `main` deploy to GitHub Pages through `.github/workflows/deploy.yml`. Use a custom domain (set `SITE` and add a `CNAME`) so links don't break under `/repo-name/`. Without one, set `BASE=/<repo-name>/` in the workflow.

## Licences

- Code: [MIT](LICENSE)
- Course content: [CC BY 4.0](LICENSE-CONTENT.md)
- Code blocks and YAML inside `content/` are MIT. See [LICENSING.md](LICENSING.md).

Nothing free in this project will ever become paid. See [FUNDING.md](FUNDING.md).

---

<p>
  <a href="https://www.aimbytes.com/"><img src="docs/assets/aimbytes-mark.png" width="20" height="20" alt="Aimbytes" align="absmiddle"></a>
  Built and maintained by <a href="https://www.aimbytes.com/">Aimbytes</a>.
</p>
