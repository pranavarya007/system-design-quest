import { useEffect, useMemo, useState } from "react";
import { simulate } from "@sdq/sim-engine";
import { toSimConfig } from "@sdq/schema/convert";
import type { Scenario } from "@sdq/schema";
import { recordEvent } from "@sdq/game";
import { SimStage } from "./SimStage";
import { Timeline } from "./Timeline";
import { Readouts, fmtMs } from "./Readouts";
import { prefersReducedMotion, usePlayback } from "./usePlayback";

type Phase = "predict" | "run" | "fix";

/**
 * Lesson island: the learner commits to a prediction, watches the run, then changes a control
 * until the scenario's goal is met. Every number shown comes from the deterministic engine.
 */
export default function PredictThenRun({ scenario }: { scenario: Scenario & { slug: string } }) {
  const predict = scenario.predict;
  const control = scenario.controls.find((c) => c.param === "workers");
  const baseWorkers = (() => {
    const n = scenario.nodes.find((x) => x.id === control?.node);
    return n?.kind === "server" ? n.workers : 1;
  })();

  const [phase, setPhase] = useState<Phase>(predict ? "predict" : "run");
  const [choice, setChoice] = useState<string | null>(null);
  const [locked, setLocked] = useState(false);
  const [finished, setFinished] = useState(false);
  const [workers, setWorkers] = useState(baseWorkers);
  const [runWorkers, setRunWorkers] = useState(baseWorkers);
  const [goalMet, setGoalMet] = useState(false);
  const [reduced, setReduced] = useState(false);
  useEffect(() => setReduced(prefersReducedMotion()), []);

  const result = useMemo(() => {
    const cfg = toSimConfig(scenario);
    if (control) cfg.nodes = cfg.nodes.map((n) => (n.id === control.node && n.kind === "server" ? { ...n, workers: runWorkers } : n));
    return simulate(cfg);
  }, [scenario, runWorkers]);

  const pb = usePlayback(scenario.duration, { speed: 2 });
  useEffect(() => {
    pb.setOnEnd(() => setFinished(true));
  }, []);
  useEffect(() => {
    if (pb.t >= scenario.duration) setFinished(true);
  }, [pb.t]);

  const goal = scenario.goal;
  const s = result.summary;
  const meets =
    (goal?.p99_ms === undefined || (s.p99_us ?? Infinity) / 1000 <= goal.p99_ms) &&
    (goal?.error_rate === undefined || s.error_rate <= goal.error_rate);

  useEffect(() => {
    if (finished && phase === "fix" && meets && !goalMet) {
      setGoalMet(true);
      void recordEvent("sim_goal", scenario.slug, { workers: runWorkers, p99_us: s.p99_us, error_rate: s.error_rate });
    }
  }, [finished, phase, meets]);

  const narration = useMemo(() => {
    if (runWorkers !== baseWorkers) return `Your run: server 1 has ${runWorkers} workers. Watch the latency line against the goal.`;
    let text = "";
    for (const n of scenario.narrate) if (n.at <= pb.t) text = n.text;
    return text;
  }, [pb.t, scenario.narrate, runWorkers]);

  const lock = () => {
    if (!choice || !predict) return;
    setLocked(true);
    void recordEvent(choice === predict.answer ? "prediction_correct" : "prediction_wrong", scenario.slug, { choice });
    setPhase("run");
    setFinished(false);
    pb.seek(0);
    if (reduced) pb.seek(scenario.duration);
    else pb.play();
  };

  const rerun = () => {
    setRunWorkers(workers);
    setFinished(false);
    pb.seek(0);
    if (reduced) pb.seek(scenario.duration);
    else pb.play();
  };

  return (
    <section aria-label={scenario.title} style={{ margin: "1.5em 0" }}>
      {predict && (
        <div style={{ marginBottom: "1em" }}>
          <h3>Predict first</h3>
          <p style={{ margin: "0.4em 0 0" }}>{predict.ask}</p>
          <fieldset className="choices" disabled={locked}>
            <legend className="sr-only">Your prediction</legend>
            {predict.options.map((o) => (
              <label key={o.id} className="choice">
                <input type="radio" name={`${scenario.slug}-predict`} value={o.id} checked={choice === o.id} onChange={() => setChoice(o.id)} />
                <span>{o.text}</span>
              </label>
            ))}
          </fieldset>
          {!locked && (
            <button type="button" className="btn" disabled={!choice} onClick={lock}>
              Lock in and run the simulation
            </button>
          )}
        </div>
      )}

      <div className="instrument" ref={pb.observe} aria-hidden={phase === "predict"} style={{ opacity: phase === "predict" ? 0.45 : 1 }}>
        <SimStage scenario={scenario} result={result} t={pb.t} reducedMotion={reduced} />
        <Readouts result={result} t={pb.t} server={control?.node ?? "s1"} goalP99Ms={goal?.p99_ms} />
        <div style={{ borderTop: "1px solid var(--rule)", padding: "6px 8px 2px" }}>
          <Timeline result={result} t={pb.t} goalP99Ms={goal?.p99_ms} onSeek={phase === "predict" ? undefined : pb.seek} />
        </div>
        <div className="narration" aria-live="polite">
          {phase === "predict" ? "Make your prediction to start the run." : narration}
        </div>
        <div className="instrument-bar">
          <button type="button" className="btn small ghost" disabled={phase === "predict"} onClick={() => (pb.playing ? pb.pause() : pb.play())}>
            {pb.playing ? "Pause" : "Play"}
          </button>
          <button type="button" className="btn small ghost" disabled={phase === "predict"} onClick={() => pb.seek(pb.t - 1_000_000)}>
            Back 1s
          </button>
          <button type="button" className="btn small ghost" disabled={phase === "predict"} onClick={() => pb.seek(pb.t + 1_000_000)}>
            Forward 1s
          </button>
          <label className="quiet" style={{ fontSize: "0.85rem", display: "flex", gap: 6, alignItems: "center" }}>
            Speed
            <select value={pb.speed} onChange={(e) => pb.setSpeed(Number(e.target.value))} disabled={phase === "predict"}>
              <option value={1}>1x</option>
              <option value={2}>2x</option>
              <option value={4}>4x</option>
            </select>
          </label>
          <span className="quiet num" style={{ marginLeft: "auto", fontSize: "0.85rem" }}>
            {(pb.t / 1e6).toFixed(0)}s of {(scenario.duration / 1e6).toFixed(0)}s
          </span>
        </div>
      </div>

      {locked && finished && predict && phase === "run" && (
        <div className={`callout ${choice === predict.answer ? "ok" : "bad"}`}>
          <p>
            <strong>{choice === predict.answer ? "Your prediction was right." : "Not what you predicted."}</strong> {predict.explain}
          </p>
          {control && (
            <button type="button" className="btn" onClick={() => setPhase("fix")}>
              Now fix it
            </button>
          )}
        </div>
      )}

      {phase === "fix" && control && (
        <div className="callout">
          <h3>Fix it</h3>
          <p>
            Keep p99 under {goal?.p99_ms} ms and errors under {((goal?.error_rate ?? 0) * 100).toFixed(0)}% for the whole run, even after server 2
            dies. More workers cost more, so use as few as you can.
          </p>
          <label style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
            <span>{control.label ?? control.param}</span>
            <input
              type="range"
              min={control.range?.[0] ?? 1}
              max={control.range?.[1] ?? 16}
              value={workers}
              onChange={(e) => setWorkers(Number(e.target.value))}
            />
            <strong className="num">{workers}</strong>
            <button type="button" className="btn small" onClick={rerun}>
              Run with {workers} workers
            </button>
          </label>
          {finished && runWorkers !== baseWorkers && (
            <p style={{ marginTop: "0.8em", marginBottom: 0 }} aria-live="polite">
              {meets ? (
                <>
                  <strong style={{ color: "var(--mint)" }}>Goal met with {runWorkers} workers.</strong> p99 was {fmtMs(s.p99_us)} and{" "}
                  {(s.error_rate * 100).toFixed(1)}% of requests failed, almost all in the 2 seconds before the load balancer noticed. +30 XP.
                </>
              ) : (
                <>
                  <strong style={{ color: "var(--red)" }}>Not yet.</strong> p99 was {fmtMs(s.p99_us)} and {(s.error_rate * 100).toFixed(1)}% of
                  requests failed.
                </>
              )}
            </p>
          )}
        </div>
      )}

      <aside className="callout" aria-label="What this model ignores">
        <strong>What this model ignores.</strong> {scenario.ignores}
      </aside>
    </section>
  );
}
