/**
 * Validates every scenario in content/scenarios and runs each one through the engine once.
 * Usage: pnpm validate:content
 */
import { readdirSync, readFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { simulate } from "@sdq/sim-engine";
import { parseScenarioYaml, toSimConfig } from "./index.js";

const dir = resolve(import.meta.dirname, "../../../content/scenarios");
const files = readdirSync(dir).filter((f) => f.endsWith(".yaml") || f.endsWith(".yml"));
let failed = 0;
for (const f of files) {
  try {
    const s = parseScenarioYaml(readFileSync(join(dir, f), "utf8"), f);
    const r = simulate(toSimConfig(s));
    const p99 = r.summary.p99_us === null ? "n/a" : `${(r.summary.p99_us / 1000).toFixed(0)} ms`;
    console.log(`ok   ${f}  (${r.summary.requests} requests, p99 ${p99}, errors ${(r.summary.error_rate * 100).toFixed(1)}%)`);
  } catch (e) {
    failed++;
    console.error(`FAIL ${f}\n${(e as Error).message}`);
  }
}
if (failed) process.exit(1);
console.log(`\n${files.length} scenario(s) valid.`);
