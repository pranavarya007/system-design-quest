import { useEffect, useMemo, useRef, useState } from "react";
import { simulate } from "@sdq/sim-engine";
import { toSimConfig } from "@sdq/schema/convert";
import type { Scenario } from "@sdq/schema";
import { SimStage, statusAt } from "./SimStage";
import { Readouts } from "./Readouts";
import { prefersReducedMotion, usePlayback } from "./usePlayback";

/**
 * Landing-page demo: steady traffic until the visitor kills a server.
 * The engine is deterministic, so re-running with a kill inserted at the current moment
 * reproduces everything before it exactly and only changes the future.
 */
export default function HeroSim({ scenario }: { scenario: Scenario }) {
  const [kills, setKills] = useState<{ at: number; kind: "kill" | "revive" }[]>([]);
  const reduced = useRef(false);
  useEffect(() => {
    reduced.current = prefersReducedMotion();
  }, []);

  const result = useMemo(() => {
    const cfg = toSimConfig({ ...scenario, events: [] });
    cfg.events = kills.map((k) => (k.kind === "kill" ? { at_us: k.at, kill: "s2" } : { at_us: k.at, revive: "s2" }));
    return simulate(cfg);
  }, [scenario, kills]);

  const pb = usePlayback(scenario.duration, { autoplay: true, loop: true });
  useEffect(() => {
    pb.setOnEnd(() => setKills([]));
  }, []);

  const s2 = statusAt(result, "s2", pb.t);
  const lastKill = kills.at(-1);
  const isDown = lastKill?.kind === "kill" && lastKill.at <= pb.t + 1;

  const toggle = () => {
    const at = Math.ceil(pb.t / 1000) * 1000 + 1000;
    setKills((k) => [...k, { at, kind: isDown ? "revive" : "kill" }]);
    if (!pb.playing) pb.play();
  };

  const narration = !isDown
    ? "Two servers share 180 requests a second, each about 60% busy."
    : s2 === "down-undetected"
      ? "Server 2 is down, but the load balancer is still sending it traffic."
      : "The load balancer gave up on server 2. Server 1 can't keep up on its own.";

  return (
    <div className="instrument" ref={pb.observe}>
      <SimStage scenario={scenario} result={result} t={pb.t} reducedMotion={reduced.current && !pb.playing} />
      <Readouts result={result} t={pb.t} server="s1" goalP99Ms={300} />
      <div className="narration" aria-live="polite">
        {narration}
      </div>
      <div className="instrument-bar">
        <button type="button" className={`btn small ${isDown ? "ghost" : "danger"}`} onClick={toggle}>
          {isDown ? "Bring server 2 back" : "Kill server 2"}
        </button>
        <button type="button" className="btn small ghost" onClick={() => (pb.playing ? pb.pause() : pb.play())}>
          {pb.playing ? "Pause" : "Play"}
        </button>
        <span className="quiet num" style={{ marginLeft: "auto", fontSize: "0.85rem" }}>
          {(pb.t / 1e6).toFixed(0)}s of {(scenario.duration / 1e6).toFixed(0)}s
        </span>
      </div>
    </div>
  );
}
