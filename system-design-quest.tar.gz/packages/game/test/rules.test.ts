import { describe, expect, it } from "vitest";
import { levelFor, uuidv7 } from "../src/index.js";

describe("levels", () => {
  it("needs the listed bosses, not just XP", () => {
    expect(levelFor(1_200, new Set()).title).toBe("Junior Dev");
    expect(levelFor(1_200, new Set(["numbers"])).title).toBe("Developer");
  });
});

describe("uuidv7", () => {
  it("is a valid v7 UUID and sorts by time", () => {
    const a = uuidv7(1_700_000_000_000);
    const b = uuidv7(1_700_000_000_001);
    expect(a).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
    expect(a < b).toBe(true);
  });
});
