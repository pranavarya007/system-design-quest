// Fails if any page loads more than 150 KB of gzipped JavaScript up front.
// Chunks only reached through dynamic import() (such as Supabase, loaded on sign-in) don't count.
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, resolve } from "node:path";
import { gzipSync } from "node:zlib";

const BUDGET = 150 * 1024;
const dist = resolve(import.meta.dirname, "../apps/web/dist");

const pages = [];
const walk = (dir) => {
  for (const f of readdirSync(dir)) {
    const p = join(dir, f);
    if (statSync(p).isDirectory()) walk(p);
    else if (f.endsWith(".html")) pages.push(p);
  }
};
walk(dist);

const gz = new Map();
const size = (file) => {
  if (!gz.has(file)) gz.set(file, gzipSync(readFileSync(file)).length);
  return gz.get(file);
};
const staticImports = (file, seen) => {
  if (seen.has(file)) return;
  seen.add(file);
  const src = readFileSync(file, "utf8");
  for (const m of src.matchAll(/(?:^|[;\n])\s*import\s*(?:[^"'()]*?from\s*)?["']\.\/([^"']+\.js)["']/g)) {
    staticImports(join(dist, "_astro", m[1]), seen);
  }
};

let failed = false;
for (const page of pages) {
  const html = readFileSync(page, "utf8");
  const entries = new Set();
  for (const m of html.matchAll(/(?:component-url|renderer-url|src)="[^"]*?\/_astro\/([^"]+\.js)"/g)) entries.add(m[1]);
  const seen = new Set();
  for (const e of entries) staticImports(join(dist, "_astro", e), seen);
  const total = [...seen].reduce((a, f) => a + size(f), 0);
  const rel = page.slice(dist.length) || "/";
  const ok = total <= BUDGET;
  if (!ok) failed = true;
  console.log(`${ok ? "ok  " : "OVER"} ${(total / 1024).toFixed(1).padStart(6)} KB  ${rel}`);
}
if (failed) {
  console.error(`\nA page is over the ${BUDGET / 1024} KB budget.`);
  process.exit(1);
}
