import { describe, expect, it } from "vitest";
import { simulate, type SimConfig } from "../src/index.js";

/** Erlang C: probability an arriving request has to wait in an M/M/c queue. */
function erlangC(c: number, lambda: number, mu: number): number {
  const a = lambda / mu;
  const rho = a / c;
  let sum = 0;
  let term = 1;
  for (let k = 0; k < c; k++) {
    if (k > 0) term *= a / k;
    sum += term;
  }
  const last = (term * a) / c; // a^c / c!
  const top = last / (1 - rho);
  return top / (sum + top);
}

/** Mean time in system for M/M/c, in the same units as 1/mu. */
function mmcMeanTime(c: number, lambda: number, mu: number): number {
  return erlangC(c, lambda, mu) / (c * mu - lambda) + 1 / mu;
}

const single = (rps: number, meanUs: number, workers: number, seconds: number, seed = 7): SimConfig => ({
  seed,
  duration_us: seconds * 1_000_000,
  nodes: [{ id: "s1", kind: "server", workers, queue: Infinity, service: { dist: "exponential", mean_us: meanUs } }],
  edges: [],
  traffic: [[0, rps]],
});

describe("queueing theory", () => {
  it("M/M/1 at 80% utilisation: mean time in system = 1/(mu - lambda)", () => {
    // mu = 1000/s, lambda = 800/s -> W = 1/200 s = 5 ms
    const r = simulate(single(800, 1_000, 1, 300));
    expect(r.summary.mean_us! / 5_000).toBeGreaterThan(0.95);
    expect(r.summary.mean_us! / 5_000).toBeLessThan(1.05);
  });

  it("M/M/1: latency climbs steeply as utilisation approaches 100%", () => {
    const at50 = simulate(single(500, 1_000, 1, 120)).summary.mean_us!;
    const at90 = simulate(single(900, 1_000, 1, 300)).summary.mean_us!;
    // theory: 2 ms vs 10 ms
    expect(at50 / 2_000).toBeGreaterThan(0.93);
    expect(at50 / 2_000).toBeLessThan(1.07);
    expect(at90 / at50).toBeGreaterThan(4);
  });

  it("M/M/c with 4 workers matches the Erlang C formula", () => {
    // mu = 250/s per worker, lambda = 800/s, rho = 0.8
    const expected = mmcMeanTime(4, 800, 250) * 1_000_000;
    const r = simulate(single(800, 4_000, 4, 300));
    expect(r.summary.mean_us! / expected).toBeGreaterThan(0.95);
    expect(r.summary.mean_us! / expected).toBeLessThan(1.05);
  });

  it("Little's law: average requests in system = arrival rate x mean time", () => {
    const r = simulate(single(800, 1_000, 1, 300));
    const windows = r.windows.slice(10); // skip warm-up
    const avgInSystem = windows.reduce((a, w) => a + w.in_system.s1!, 0) / windows.length;
    const predicted = 800 * (r.summary.mean_us! / 1_000_000);
    expect(avgInSystem / predicted).toBeGreaterThan(0.85);
    expect(avgInSystem / predicted).toBeLessThan(1.15);
  });

  it("reports utilisation close to lambda / (c * mu)", () => {
    const r = simulate(single(800, 4_000, 4, 120));
    const u = r.windows.slice(5).reduce((a, w) => a + w.utilisation.s1!, 0) / (r.windows.length - 5);
    expect(u).toBeGreaterThan(0.77);
    expect(u).toBeLessThan(0.83);
  });
});

describe("determinism", () => {
  it("the same seed gives identical results", () => {
    const a = simulate(single(700, 1_000, 1, 20, 42));
    const b = simulate(single(700, 1_000, 1, 20, 42));
    expect(a.summary).toEqual(b.summary);
    expect(a.attempts.length).toBe(b.attempts.length);
  });

  it("a different seed gives different samples", () => {
    const a = simulate(single(700, 1_000, 1, 20, 1));
    const b = simulate(single(700, 1_000, 1, 20, 2));
    expect(a.summary.mean_us).not.toBe(b.summary.mean_us);
  });
});
