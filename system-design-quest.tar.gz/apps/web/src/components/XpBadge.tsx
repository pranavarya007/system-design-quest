import { useEffect, useState } from "react";
import { levelFor, localXp, onProgressChange } from "@sdq/game";
import { getClient, signInWithGitHub, signOut, syncEnabled, syncNow } from "../lib/sync";

/** Header widget: XP and level from this device, plus GitHub sign-in when sync is configured. */
export default function XpBadge() {
  const [xp, setXp] = useState<number | null>(null);
  const [user, setUser] = useState<string | null>(null);

  useEffect(() => {
    const refresh = () => void localXp().then(setXp);
    refresh();
    const off = onProgressChange(() => {
      refresh();
      void syncNow().catch(() => {});
    });
    return () => void off();
  }, []);

  useEffect(() => {
    const c = getClient();
    if (!c) return;
    void c.then(async (client) => {
      const { data } = await client.auth.getSession();
      setUser(data.session?.user.user_metadata?.user_name ?? data.session?.user.email ?? null);
      if (data.session) void syncNow().catch(() => {});
      client.auth.onAuthStateChange((_e, session) => setUser(session?.user.user_metadata?.user_name ?? null));
    });
  }, []);

  const level = xp === null ? null : levelFor(xp, new Set());
  return (
    <div style={{ display: "flex", gap: 10, alignItems: "center", fontSize: "0.88rem" }}>
      {xp !== null && (
        <span title="XP is saved on this device" aria-live="polite">
          <strong className="num">{xp} XP</strong> <span className="quiet">{level?.title}</span>
        </span>
      )}
      {syncEnabled &&
        (user ? (
          <button type="button" className="btn small ghost" onClick={() => void signOut()}>
            Sign out {user}
          </button>
        ) : (
          <button type="button" className="btn small ghost" onClick={() => void signInWithGitHub()}>
            Sign in with GitHub
          </button>
        ))}
    </div>
  );
}
