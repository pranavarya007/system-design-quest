import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { parseScenarioYaml, type Scenario } from "@sdq/schema";

const root = resolve(process.cwd(), "../../content/scenarios");

/** Load and validate a scenario at build time. A broken scenario fails the build with a readable message. */
export function loadScenario(name: string): Scenario & { slug: string } {
  const file = resolve(root, `${name}.yaml`);
  const scenario = parseScenarioYaml(readFileSync(file, "utf8"), `${name}.yaml`);
  return { ...scenario, slug: name };
}
