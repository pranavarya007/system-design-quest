import type { NodeSpec, SimConfig } from "@sdq/sim-engine";
import type { Scenario } from "./scenario.js";

/** Convert a validated scenario into an engine config. */
export function toSimConfig(s: Scenario, overrides: { seed?: number } = {}): SimConfig {
  const nodes: NodeSpec[] = s.nodes.map((n) => {
    if (n.kind === "lb") return { id: n.id, kind: "lb", algo: n.algo, health_check_us: n.health_check };
    const sm = n.service_ms;
    const service =
      "p50" in sm
        ? ({ dist: "lognormal", p50_us: sm.p50 * 1_000, p99_us: sm.p99 * 1_000 } as const)
        : "mean" in sm
          ? ({ dist: "exponential", mean_us: sm.mean * 1_000 } as const)
          : ({ dist: "deterministic", us: sm.fixed * 1_000 } as const);
    return {
      id: n.id,
      kind: "server",
      workers: n.workers,
      queue: n.queue === "unbounded" ? Infinity : n.queue,
      service,
    };
  });
  return {
    seed: overrides.seed ?? s.seed,
    duration_us: s.duration,
    nodes,
    edges: s.edges,
    traffic: s.traffic.rps,
    client: {
      timeout_us: s.client.timeout,
      retries: s.client.retries,
      backoff_us: s.client.backoff,
      jitter: s.client.jitter,
    },
    events: s.events.map((e) => ({ at_us: e.at, kill: e.kill, revive: e.revive })),
  };
}
