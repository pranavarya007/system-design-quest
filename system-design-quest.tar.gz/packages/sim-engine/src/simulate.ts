import { EventHeap } from "./heap.js";
import { createRng } from "./random.js";
import type {
  AttemptRecord,
  LbSpec,
  NodeEvent,
  Outcome,
  RequestRecord,
  ServerSpec,
  SimConfig,
  SimResult,
  Summary,
  Window,
} from "./types.js";

export const ENGINE_VERSION = "0.1.0";

/** Time a client waits to learn that a connection was refused by a dead server. */
const REFUSED_US = 1_000;
const DEFAULT_HEALTH_CHECK_US = 2_000_000;

type Ev =
  | { k: "arrival" }
  | { k: "send"; req: number }
  | { k: "done"; server: string; epoch: number; att: number }
  | { k: "refused"; att: number }
  | { k: "timeout"; att: number }
  | { k: "kill"; node: string }
  | { k: "revive"; node: string }
  | { k: "lb_mark"; node: string; up: boolean }
  | { k: "sample"; w: number };

interface Req {
  id: number;
  arrived: number;
  attempts: number;
  done: boolean;
  outcome: Outcome;
  end: number;
}

interface ServerState {
  spec: ServerSpec;
  up: boolean;
  epoch: number;
  busy: number;
  /** Attempt indices currently being served. */
  serving: Set<number>;
  queue: number[];
  qHead: number;
}

const percentile = (sorted: number[], p: number): number | null => {
  if (sorted.length === 0) return null;
  const i = Math.min(sorted.length - 1, Math.max(0, Math.ceil(p * sorted.length) - 1));
  return sorted[i]!;
};

/**
 * Discrete-event simulation of clients -> (optional load balancer) -> servers.
 * Deterministic: the same config (including seed) always gives the same result.
 */
export function simulate(config: SimConfig): SimResult {
  const rng = createRng(config.seed);
  const heap = new EventHeap<Ev>();
  const windowUs = config.window_us ?? 1_000_000;
  const end = config.duration_us;
  const client = config.client ?? {};
  const retries = client.retries ?? 0;

  const lbs = new Map<string, LbSpec>();
  const servers = new Map<string, ServerState>();
  for (const n of config.nodes) {
    if (n.kind === "lb") lbs.set(n.id, n);
    else
      servers.set(n.id, {
        spec: n,
        up: true,
        epoch: 0,
        busy: 0,
        serving: new Set(),
        queue: [],
        qHead: 0,
      });
  }

  const entry =
    config.entry ?? config.nodes.find((n) => n.kind === "lb")?.id ?? config.nodes[0]?.id;
  if (!entry) throw new Error("Scenario has no nodes");

  const backends = new Map<string, string[]>();
  for (const [from, to] of config.edges) {
    if (!servers.has(to)) continue;
    const list = backends.get(from) ?? [];
    list.push(to);
    backends.set(from, list);
  }
  /** What each load balancer believes is healthy. */
  const believedUp = new Map<string, Set<string>>();
  for (const id of lbs.keys()) believedUp.set(id, new Set(backends.get(id) ?? []));
  const rr = new Map<string, number>();
  /** In-flight attempts the load balancer has sent to each backend (for least connections). */
  const inflight = new Map<string, number>();

  const requests: Req[] = [];
  const attempts: (AttemptRecord & { req: number })[] = [];
  const nodeEvents: NodeEvent[] = [];
  /** Attempts whose outcome the client already knows (ok, failed, rejected or timed out). */
  const settled = new Set<number>();

  // Windows
  const nWindows = Math.max(1, Math.ceil(end / windowUs));
  const wLat: number[][] = Array.from({ length: nWindows }, () => []);
  const wOffered = new Array<number>(nWindows).fill(0);
  const wErr = new Array<number>(nWindows).fill(0);
  const wAtt = new Array<number>(nWindows).fill(0);
  const wBusy = new Map<string, number[]>();
  const wInSys = new Map<string, number[]>();
  for (const id of servers.keys()) {
    wBusy.set(id, new Array<number>(nWindows).fill(0));
    wInSys.set(id, new Array<number>(nWindows).fill(0));
  }
  const widx = (t: number) => Math.min(nWindows - 1, Math.floor(t / windowUs));
  /** Spread a busy interval across the windows it covers. */
  const addBusy = (server: string, from: number, to: number) => {
    const arr = wBusy.get(server)!;
    let t = Math.max(0, from);
    const stop = Math.min(to, end);
    while (t < stop) {
      const w = widx(t);
      const wEnd = (w + 1) * windowUs;
      const seg = Math.min(stop, wEnd) - t;
      arr[w]! += seg;
      t += seg;
      if (w === nWindows - 1 && t >= wEnd) break;
    }
  };

  // ---- traffic ----
  const schedule = [...config.traffic].sort((a, b) => a[0] - b[0]);
  const rateAt = (t: number): { rps: number; until: number } => {
    let rps = 0;
    let until = Infinity;
    for (let i = 0; i < schedule.length; i++) {
      const [st, r] = schedule[i]!;
      if (st <= t) {
        rps = r;
        until = schedule[i + 1]?.[0] ?? Infinity;
      }
    }
    return { rps, until };
  };
  const scheduleNextArrival = (from: number) => {
    let t = from;
    for (;;) {
      const { rps, until } = rateAt(t);
      if (rps <= 0) {
        if (until === Infinity) return;
        t = until;
        continue;
      }
      const gap = Math.max(1, Math.round(rng.exponential(1_000_000 / rps)));
      if (t + gap >= until) {
        t = until; // memoryless: restart at the rate change
        continue;
      }
      if (t + gap < end) heap.push(t + gap, { k: "arrival" });
      return;
    }
  };

  // ---- helpers ----
  const finishRequest = (r: Req, t: number, outcome: Outcome) => {
    r.done = true;
    r.outcome = outcome;
    r.end = t;
    if (outcome === "ok") wLat[widx(t)]!.push(t - r.arrived);
    else wErr[widx(t)]! += 1;
  };

  const failAttempt = (attIdx: number, t: number, outcome: Outcome) => {
    if (settled.has(attIdx)) return;
    settled.add(attIdx);
    const a = attempts[attIdx]!;
    a.end_us = t;
    a.outcome = outcome;
    const r = requests[a.req]!;
    if (r.done) return;
    if (r.attempts <= retries) {
      const base = (client.backoff_us ?? 0) * 2 ** (r.attempts - 1);
      const delay = client.jitter ? Math.round(rng.next() * base) : base;
      heap.push(t + delay, { k: "send", req: r.id });
    } else {
      finishRequest(r, t, outcome);
    }
  };

  const startService = (s: ServerState, attIdx: number, t: number) => {
    s.busy += 1;
    s.serving.add(attIdx);
    const a = attempts[attIdx]!;
    a.start_us = t;
    const dur = rng.service(s.spec.service);
    addBusy(s.spec.id, t, t + dur);
    heap.push(t + dur, { k: "done", server: s.spec.id, epoch: s.epoch, att: attIdx });
  };

  const pickBackend = (lbId: string): string | null => {
    const lb = lbs.get(lbId)!;
    const all = backends.get(lbId) ?? [];
    const healthy = all.filter((b) => believedUp.get(lbId)!.has(b));
    if (healthy.length === 0) return null;
    switch (lb.algo) {
      case "round_robin": {
        const i = rr.get(lbId) ?? 0;
        rr.set(lbId, i + 1);
        return healthy[i % healthy.length]!;
      }
      case "random":
        return healthy[Math.floor(rng.next() * healthy.length)]!;
      case "least_connections": {
        let best = healthy[0]!;
        for (const b of healthy) if ((inflight.get(b) ?? 0) < (inflight.get(best) ?? 0)) best = b;
        return best;
      }
    }
  };

  const send = (r: Req, t: number) => {
    r.attempts += 1;
    wAtt[widx(t)]! += 1;
    const attIdx = attempts.length;
    const target = lbs.has(entry) ? pickBackend(entry) : entry;
    attempts.push({
      req: r.id,
      attempt: r.attempts,
      sent_us: t,
      server: target,
      end_us: t,
      outcome: "ok",
    });
    if (client.timeout_us !== undefined) heap.push(t + client.timeout_us, { k: "timeout", att: attIdx });
    if (target === null) {
      failAttempt(attIdx, t, "rejected");
      return;
    }
    const s = servers.get(target)!;
    if (!s.up) {
      heap.push(t + REFUSED_US, { k: "refused", att: attIdx });
      return;
    }
    inflight.set(target, (inflight.get(target) ?? 0) + 1);
    if (s.busy < s.spec.workers) startService(s, attIdx, t);
    else if (s.queue.length - s.qHead < s.spec.queue) s.queue.push(attIdx);
    else {
      inflight.set(target, inflight.get(target)! - 1);
      failAttempt(attIdx, t, "rejected");
    }
  };

  const releaseInflight = (server: string) => inflight.set(server, Math.max(0, (inflight.get(server) ?? 1) - 1));

  // ---- seed the event queue ----
  scheduleNextArrival(0);
  for (const e of config.events ?? []) {
    if (e.kill) heap.push(e.at_us, { k: "kill", node: e.kill });
    if (e.revive) heap.push(e.at_us, { k: "revive", node: e.revive });
  }
  for (let w = 0; w < nWindows; w++) heap.push(Math.min(end, (w + 1) * windowUs), { k: "sample", w });

  // ---- main loop ----
  for (;;) {
    const item = heap.pop();
    if (!item) break;
    const { t, v: ev } = item;
    if (t > end) break;
    switch (ev.k) {
      case "arrival": {
        const r: Req = { id: requests.length, arrived: t, attempts: 0, done: false, outcome: "ok", end: t };
        requests.push(r);
        wOffered[widx(t)]! += 1;
        send(r, t);
        scheduleNextArrival(t);
        break;
      }
      case "send": {
        const r = requests[ev.req]!;
        if (!r.done) send(r, t);
        break;
      }
      case "done": {
        const s = servers.get(ev.server)!;
        if (ev.epoch !== s.epoch) break; // server died while this was in service
        s.busy -= 1;
        s.serving.delete(ev.att);
        releaseInflight(ev.server);
        const a = attempts[ev.att]!;
        const r = requests[a.req]!;
        if (!settled.has(ev.att)) {
          settled.add(ev.att);
          a.end_us = t;
          a.outcome = "ok";
          if (!r.done) finishRequest(r, t, "ok");
        }
        // a timed-out attempt still used the worker: wasted work, no response delivered
        while (s.busy < s.spec.workers && s.qHead < s.queue.length) {
          const next = s.queue[s.qHead++]!;
          startService(s, next, t);
        }
        if (s.qHead > 1024 && s.qHead * 2 > s.queue.length) {
          s.queue = s.queue.slice(s.qHead);
          s.qHead = 0;
        }
        break;
      }
      case "refused":
        failAttempt(ev.att, t, "failed");
        break;
      case "timeout": {
        // still waiting: the client gives up, but the server keeps working on it
        failAttempt(ev.att, t, "timeout");
        break;
      }
      case "kill": {
        const s = servers.get(ev.node);
        if (!s || !s.up) break;
        s.up = false;
        s.epoch += 1;
        nodeEvents.push({ at_us: t, node: ev.node, type: "down" });
        const lost = [...s.serving, ...s.queue.slice(s.qHead)];
        s.serving.clear();
        s.queue = [];
        s.qHead = 0;
        s.busy = 0;
        inflight.set(ev.node, 0);
        for (const att of lost) failAttempt(att, t, "failed");
        for (const [lbId, lb] of lbs)
          if ((backends.get(lbId) ?? []).includes(ev.node))
            heap.push(t + (lb.health_check_us ?? DEFAULT_HEALTH_CHECK_US), { k: "lb_mark", node: ev.node, up: false });
        break;
      }
      case "revive": {
        const s = servers.get(ev.node);
        if (!s || s.up) break;
        s.up = true;
        nodeEvents.push({ at_us: t, node: ev.node, type: "up" });
        for (const [lbId, lb] of lbs)
          if ((backends.get(lbId) ?? []).includes(ev.node))
            heap.push(t + (lb.health_check_us ?? DEFAULT_HEALTH_CHECK_US), { k: "lb_mark", node: ev.node, up: true });
        break;
      }
      case "lb_mark": {
        const s = servers.get(ev.node);
        if (!s || s.up !== ev.up) break; // state flipped again before the check noticed
        for (const [lbId, set] of believedUp) {
          if (!(backends.get(lbId) ?? []).includes(ev.node)) continue;
          if (ev.up) set.add(ev.node);
          else set.delete(ev.node);
        }
        nodeEvents.push({ at_us: t, node: ev.node, type: ev.up ? "lb_marked_up" : "lb_marked_down" });
        break;
      }
      case "sample":
        for (const [id, s] of servers) wInSys.get(id)![ev.w] = s.busy + (s.queue.length - s.qHead);
        break;
    }
  }

  // Requests still open at the end are left out of the summary (censored), not counted as errors.
  const closed = requests.filter((r) => r.done);
  const okLat = closed.filter((r) => r.outcome === "ok").map((r) => r.end - r.arrived).sort((a, b) => a - b);
  const errors = closed.length - okLat.length;
  const summary: Summary = {
    requests: closed.length,
    ok: okLat.length,
    errors,
    error_rate: closed.length ? errors / closed.length : 0,
    mean_us: okLat.length ? okLat.reduce((a, b) => a + b, 0) / okLat.length : null,
    p50_us: percentile(okLat, 0.5),
    p99_us: percentile(okLat, 0.99),
    attempts: attempts.length,
    throughput_rps: okLat.length / (end / 1_000_000),
  };

  const windows: Window[] = [];
  for (let w = 0; w < nWindows; w++) {
    const lat = wLat[w]!.sort((a, b) => a - b);
    const span = Math.min(windowUs, end - w * windowUs);
    const utilisation: Record<string, number> = {};
    const in_system: Record<string, number> = {};
    for (const [id, s] of servers) {
      utilisation[id] = Math.min(1, wBusy.get(id)![w]! / (span * s.spec.workers));
      in_system[id] = wInSys.get(id)![w]!;
    }
    windows.push({
      start_us: w * windowUs,
      offered: wOffered[w]!,
      ok: lat.length,
      errors: wErr[w]!,
      attempts: wAtt[w]!,
      p50_us: percentile(lat, 0.5),
      p99_us: percentile(lat, 0.99),
      utilisation,
      in_system,
    });
  }

  return {
    engine_version: ENGINE_VERSION,
    config,
    requests: requests.map(({ id, arrived, end: e, attempts: n, outcome }) => ({
      id,
      arrived_us: arrived,
      end_us: e,
      attempts: n,
      outcome,
    })) satisfies RequestRecord[],
    attempts,
    node_events: nodeEvents,
    windows,
    summary,
  };
}
