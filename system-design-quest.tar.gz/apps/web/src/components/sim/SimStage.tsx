import { useEffect, useMemo, useRef, useState } from "react";
import type { SimResult } from "@sdq/sim-engine";
import type { Scenario } from "@sdq/schema";

/** Visual travel time of a request from client to server, in simulated microseconds. */
const TRAVEL_US = 450_000;
const MAX_DOTS = 140;
/** Below this rendered width the stage switches to a top-down layout that stays legible on phones. */
const NARROW_PX = 560;

interface Props {
  scenario: Scenario;
  result: SimResult;
  t: number;
  /** Shown in place of moving dots when the reader prefers reduced motion. */
  reducedMotion?: boolean;
}

type ServerStatus = "up" | "down-undetected" | "down";

export function statusAt(result: SimResult, node: string, t: number): ServerStatus {
  let s: ServerStatus = "up";
  for (const e of result.node_events) {
    if (e.at_us > t || e.node !== node) continue;
    if (e.type === "down") s = "down-undetected";
    if (e.type === "lb_marked_down") s = "down";
    if (e.type === "up") s = "up";
  }
  return s;
}

interface Pt {
  x: number;
  y: number;
}
interface Geometry {
  W: number;
  H: number;
  users: Pt[];
  usersLabel: Pt;
  usersOut: Pt;
  lb: { x: number; y: number; w: number; h: number };
  lbIn: Pt;
  lbOut: Pt;
  server: (i: number) => { x: number; y: number; w: number; h: number; in: Pt };
  /** Where the "N waiting" label goes, relative to the server box. */
  queueLabelInside: boolean;
}

function layout(n: number, narrow: boolean): Geometry {
  if (!narrow) {
    const W = 700;
    const rowH = 96;
    const H = Math.max(240, 56 + n * rowH);
    const midY = H / 2;
    const srvX = 430;
    const srvW = 170;
    const y0 = (H - (n * rowH - 28)) / 2;
    return {
      W,
      H,
      users: [-1, 0, 1].map((k) => ({ x: 54, y: midY + k * 18 })),
      usersLabel: { x: 54, y: midY + 46 },
      usersOut: { x: 78, y: midY },
      lb: { x: 210, y: midY - 26, w: 80, h: 52 },
      lbIn: { x: 210, y: midY },
      lbOut: { x: 290, y: midY },
      server: (i) => {
        const y = y0 + i * rowH;
        return { x: srvX, y, w: srvW, h: 68, in: { x: srvX, y: y + 34 } };
      },
      queueLabelInside: false,
    };
  }
  const W = 360;
  const H = 330;
  const gap = 12;
  const sw = (W - 32 - gap * (n - 1)) / n;
  return {
    W,
    H,
    users: [-1, 0, 1].map((k) => ({ x: W / 2 + k * 20, y: 26 })),
    usersLabel: { x: W / 2 + 44, y: 30 },
    usersOut: { x: W / 2, y: 36 },
    lb: { x: W / 2 - 44, y: 104, w: 88, h: 48 },
    lbIn: { x: W / 2, y: 104 },
    lbOut: { x: W / 2, y: 152 },
    server: (i) => {
      const x = 16 + i * (sw + gap);
      return { x, y: 222, w: sw, h: 92, in: { x: x + sw / 2, y: 222 } };
    },
    queueLabelInside: true,
  };
}

/**
 * SVG picture of clients -> load balancer -> servers at simulated time t.
 * Everything is read from the engine's event log, so the picture can never disagree with the numbers.
 */
export function SimStage({ scenario, result, t, reducedMotion }: Props) {
  const servers = scenario.nodes.filter((n) => n.kind === "server");
  const lbNode = scenario.nodes.find((n) => n.kind === "lb");
  const ref = useRef<HTMLDivElement>(null);
  const [narrow, setNarrow] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(([e]) => setNarrow((e?.contentRect.width ?? 999) < NARROW_PX));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const g = layout(servers.length, narrow);
  const serverIndex = new Map(servers.map((s, i) => [s.id, i]));
  const w = result.windows[Math.min(result.windows.length - 1, Math.max(0, Math.floor(t / 1_000_000) - 1))];
  const lerp = (a: Pt, b: Pt, q: number): Pt => ({ x: a.x + (b.x - a.x) * q, y: a.y + (b.y - a.y) * q });

  // Requests in flight right now (sent within the last TRAVEL_US).
  const dots = useMemo(() => {
    if (reducedMotion) return [];
    const out: { x: number; y: number; bad: boolean }[] = [];
    const atts = result.attempts;
    let lo = 0;
    let hi = atts.length;
    const from = t - TRAVEL_US;
    while (lo < hi) {
      const m = (lo + hi) >> 1;
      if (atts[m]!.sent_us < from) lo = m + 1;
      else hi = m;
    }
    let count = 0;
    for (let i = lo; i < atts.length && atts[i]!.sent_us <= t; i++) count++;
    const step = Math.max(1, Math.ceil(count / MAX_DOTS));
    for (let i = lo; i < lo + count; i += step) {
      const a = atts[i]!;
      const p = (t - a.sent_us) / TRAVEL_US;
      const si = a.server ? serverIndex.get(a.server) : undefined;
      const jitter = ((a.req * 2654435761) % 1000) / 1000 - 0.5;
      const failsFast = a.outcome !== "ok" && a.outcome !== "timeout" && a.end_us <= a.sent_us + TRAVEL_US;
      const bad = failsFast && p > 0.85;
      if (p < 0.45 || si === undefined) {
        const q = Math.min(1, p / 0.45);
        const pt = lerp(g.usersOut, g.lbIn, q);
        out.push(narrow ? { x: pt.x + jitter * 22 * (1 - q), y: pt.y, bad } : { x: pt.x, y: pt.y + jitter * 26 * (1 - q), bad });
      } else {
        const pt = lerp(g.lbOut, g.server(si).in, (p - 0.45) / 0.55);
        out.push({ x: pt.x + (narrow ? jitter * 6 : 0), y: pt.y + (narrow ? 0 : jitter * 6), bad });
      }
    }
    return out;
  }, [result, t, reducedMotion, narrow]);

  const label = `Load balancer sending traffic to ${servers.length} servers at ${(t / 1e6).toFixed(0)} seconds`;

  return (
    <div ref={ref}>
      <svg viewBox={`0 0 ${g.W} ${g.H}`} role="img" aria-label={label} style={{ display: "block", width: "100%", height: "auto" }}>
        <defs>
          <pattern id="sdq-grid" width="16" height="16" patternUnits="userSpaceOnUse">
            <path d="M16 0H0V16" fill="none" stroke="var(--grid)" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width={g.W} height={g.H} fill="url(#sdq-grid)" />

        <g stroke="var(--rule)" strokeWidth="1.5" fill="none">
          <line x1={g.usersOut.x} y1={g.usersOut.y} x2={g.lbIn.x} y2={g.lbIn.y} />
          {servers.map((s, i) => {
            const to = g.server(i).in;
            return <line key={s.id} x1={g.lbOut.x} y1={g.lbOut.y} x2={to.x} y2={to.y} />;
          })}
        </g>

        <g>
          {g.users.map((u, k) => (
            <circle key={k} cx={u.x} cy={u.y} r="7" fill="none" stroke="var(--ink-2)" strokeWidth="1.5" />
          ))}
          <text x={g.usersLabel.x} y={g.usersLabel.y} textAnchor={narrow ? "start" : "middle"} fontSize="12" fill="var(--ink-2)">
            Users
          </text>
        </g>

        {lbNode && (
          <g>
            <rect x={g.lb.x} y={g.lb.y} width={g.lb.w} height={g.lb.h} rx="8" fill="var(--panel)" stroke="var(--ink)" strokeWidth="1.5" />
            <text x={g.lb.x + g.lb.w / 2} y={g.lb.y + g.lb.h / 2 + 4} textAnchor="middle" fontSize="13" fontWeight="650" fill="var(--ink)">
              LB
            </text>
            <text
              x={narrow ? g.lb.x + g.lb.w + 10 : g.lb.x + g.lb.w / 2}
              y={narrow ? g.lb.y + g.lb.h / 2 + 4 : g.lb.y + g.lb.h + 20}
              textAnchor={narrow ? "start" : "middle"}
              fontSize="12"
              fill="var(--ink-2)"
            >
              {lbNode.label ?? "Load balancer"}
            </text>
          </g>
        )}

        {servers.map((s, i) => {
          if (s.kind !== "server") return null;
          const b = g.server(i);
          const status = statusAt(result, s.id, t);
          const down = status !== "up";
          const inSys = w?.in_system[s.id] ?? 0;
          const busy = down ? 0 : Math.min(s.workers, inSys);
          const queued = down ? 0 : Math.max(0, inSys - s.workers);
          const cap = s.queue === "unbounded" ? Math.max(50, queued) : s.queue;
          const cols = Math.min(s.workers, 16);
          const cell = Math.max(5, Math.min(14, (b.w - 24) / cols - 3));
          const statusText = status === "up" ? `${s.workers} workers` : status === "down" ? "Down" : narrow ? "Down" : "Down, LB unaware";
          const gaugeY = b.y + (narrow ? 66 : 54);
          return (
            <g key={s.id}>
              <rect
                x={b.x}
                y={b.y}
                width={b.w}
                height={b.h}
                rx="8"
                fill="var(--panel)"
                stroke={down ? "var(--red)" : "var(--ink)"}
                strokeWidth="1.5"
                strokeDasharray={down ? "5 4" : undefined}
              />
              <text x={b.x + 12} y={b.y + 20} fontSize="13" fontWeight="650" fill="var(--ink)">
                {s.label ?? s.id}
              </text>
              <text
                x={narrow ? b.x + 12 : b.x + b.w - 12}
                y={narrow ? b.y + 37 : b.y + 20}
                textAnchor={narrow ? "start" : "end"}
                fontSize="11.5"
                fill={down ? "var(--red)" : "var(--ink-2)"}
              >
                {statusText}
              </text>
              {Array.from({ length: cols }, (_, k) => (
                <rect
                  key={k}
                  x={b.x + 12 + k * (cell + 3)}
                  y={b.y + (narrow ? 46 : 32)}
                  width={cell}
                  height={cell}
                  rx="2"
                  fill={k < busy ? "var(--cobalt)" : "none"}
                  stroke={down ? "var(--red)" : "var(--ink-3)"}
                  strokeWidth="1"
                />
              ))}
              <rect x={b.x + 12} y={gaugeY} width={b.w - 24} height="5" rx="2.5" fill="var(--grid)" />
              <rect x={b.x + 12} y={gaugeY} width={(b.w - 24) * Math.min(1, queued / cap)} height="5" rx="2.5" fill="var(--amber)" />
              <text
                x={g.queueLabelInside ? b.x + 12 : b.x + b.w + 8}
                y={g.queueLabelInside ? gaugeY + 19 : gaugeY + 5}
                fontSize="11.5"
                fill={queued > 0 ? "var(--amber)" : "var(--ink-3)"}
                className="num"
              >
                {queued > 0 ? `${queued} waiting` : "no queue"}
              </text>
            </g>
          );
        })}

        <g>
          {dots.map((d, i) => (
            <circle key={i} cx={d.x} cy={d.y} r="3.2" fill={d.bad ? "var(--red)" : "var(--cobalt)"} />
          ))}
        </g>
      </svg>
    </div>
  );
}
