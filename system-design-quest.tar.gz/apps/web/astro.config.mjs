import { defineConfig } from "astro/config";
import mdx from "@astrojs/mdx";
import react from "@astrojs/react";
import tailwindcss from "@tailwindcss/vite";

// SITE is the public URL. Use a custom domain (recommended) so BASE stays "/".
// Without one, set BASE to "/<repo-name>/" for https://<user>.github.io/<repo-name>/.
export default defineConfig({
  site: process.env.SITE ?? "https://systemdesignquest.example",
  base: process.env.BASE ?? "/",
  trailingSlash: "always",
  integrations: [react(), mdx()],
  vite: {
    plugins: [tailwindcss()],
  },
});
