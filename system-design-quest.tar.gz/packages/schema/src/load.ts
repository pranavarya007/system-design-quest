import { parse } from "yaml";
import { ScenarioSchema, type Scenario } from "./scenario.js";

/** Parse and validate scenario YAML. Throws a readable error listing every problem. */
export function parseScenarioYaml(text: string, file = "scenario"): Scenario {
  const raw = parse(text);
  const result = ScenarioSchema.safeParse(raw);
  if (!result.success) {
    const lines = result.error.issues.map((i) => `  ${file}: ${i.path.join(".") || "(root)"}: ${i.message}`);
    throw new Error(`Invalid scenario\n${lines.join("\n")}`);
  }
  return result.data;
}
