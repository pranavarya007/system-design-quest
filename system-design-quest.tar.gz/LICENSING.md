# Which licence covers what

| What | Licence |
| --- | --- |
| Everything in `packages/`, `apps/`, `supabase/`, `.github/` | MIT ([LICENSE](LICENSE)) |
| Scenario, flow and challenge files (`content/**/*.yaml`) | MIT |
| Code blocks inside lessons (fenced code in `.mdx`) | MIT |
| Lesson prose, quizzes, case-study text, diagrams and images | CC BY 4.0 ([LICENSE-CONTENT.md](LICENSE-CONTENT.md)) |
| The Aimbytes name and logo (`apps/web/public/brand/`, `docs/assets/aimbytes-*`) | Not licensed for reuse. Ask Aimbytes. |

Scenarios are MIT so that anyone, including other courses, can reuse them as code without attribution rules getting in the way.

## Contributions

By contributing you agree your work is released under the licence above for that kind of file. Every commit needs a [Developer Certificate of Origin](https://developercertificate.org/) sign-off:

```bash
git commit -s -m "Add cache stampede scenario"
```

There is no CLA. You keep the copyright to your contributions.

## Company names in case studies

Case studies use company names only to say whose public talks and papers they draw on. They carry no logos, every diagram is redrawn, guessed parts are marked as inferred, and each page says it is not affiliated with the company. To request a correction or removal, open an issue with the `correction` label.
