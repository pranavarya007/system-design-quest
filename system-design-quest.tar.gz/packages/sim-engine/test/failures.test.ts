import { describe, expect, it } from "vitest";
import { simulate, type SimConfig } from "../src/index.js";

const lbScenario = (over: Partial<SimConfig> = {}): SimConfig => ({
  seed: 3,
  duration_us: 40_000_000,
  nodes: [
    { id: "lb", kind: "lb", algo: "round_robin", health_check_us: 2_000_000 },
    { id: "s1", kind: "server", workers: 4, queue: 50, service: { dist: "lognormal", p50_us: 20_000, p99_us: 120_000 } },
    { id: "s2", kind: "server", workers: 4, queue: 50, service: { dist: "lognormal", p50_us: 20_000, p99_us: 120_000 } },
  ],
  edges: [
    ["lb", "s1"],
    ["lb", "s2"],
  ],
  traffic: [[0, 150]],
  ...over,
});

describe("failures", () => {
  it("killing a server causes errors until the load balancer notices", () => {
    const r = simulate(lbScenario({ events: [{ at_us: 20_000_000, kill: "s2" }] }));
    const before = r.windows.slice(5, 19).reduce((a, w) => a + w.errors, 0);
    const during = r.windows[20]!.errors + r.windows[21]!.errors;
    expect(before).toBe(0);
    expect(during).toBeGreaterThan(50);
    expect(r.node_events.map((e) => e.type)).toEqual(["down", "lb_marked_down"]);
    expect(r.node_events[1]!.at_us).toBe(22_000_000);
  });

  it("a full queue rejects requests instead of waiting forever", () => {
    const r = simulate(lbScenario({ traffic: [[0, 1_000]] }));
    expect(r.attempts.some((a) => a.outcome === "rejected")).toBe(true);
  });

  it("aggressive retries without backoff amplify load (retry storm)", () => {
    const overloaded = (retries: number) =>
      simulate(
        lbScenario({
          traffic: [[0, 320]],
          client: { timeout_us: 60_000, retries, backoff_us: 0 },
        }),
      ).summary;
    const none = overloaded(0);
    const three = overloaded(3);
    expect(three.attempts / three.requests).toBeGreaterThan(1.3);
    expect(three.attempts).toBeGreaterThan(none.attempts);
  });

  it("records every attempt with a server and an outcome for the renderer", () => {
    const r = simulate(lbScenario({ duration_us: 5_000_000 }));
    for (const a of r.attempts.slice(0, 100)) {
      expect(["s1", "s2"]).toContain(a.server);
      expect(a.end_us).toBeGreaterThanOrEqual(a.sent_us);
    }
  });
});
