import { useCallback, useEffect, useRef, useState } from "react";

export const prefersReducedMotion = () =>
  typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

/**
 * A simulation clock in microseconds. The engine has already computed the whole run;
 * this only decides which moment of it is on screen.
 */
export function usePlayback(durationUs: number, opts: { autoplay?: boolean; speed?: number; loop?: boolean } = {}) {
  const [t, setT] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(opts.speed ?? 1);
  const raf = useRef<number | null>(null);
  const last = useRef<number | null>(null);
  const tRef = useRef(0);
  const visible = useRef(true);
  const loopRef = useRef(opts.loop ?? false);
  const onEnd = useRef<(() => void) | null>(null);

  useEffect(() => {
    if (opts.autoplay && !prefersReducedMotion()) setPlaying(true);
  }, [opts.autoplay]);

  const tick = useCallback(
    (now: number) => {
      if (last.current === null) last.current = now;
      const dtMs = Math.min(100, now - last.current);
      last.current = now;
      if (visible.current) {
        let next = tRef.current + dtMs * 1000 * speed;
        if (next >= durationUs) {
          if (loopRef.current) {
            next = 0;
            onEnd.current?.();
          } else {
            next = durationUs;
            setPlaying(false);
            onEnd.current?.();
          }
        }
        tRef.current = next;
        setT(next);
      }
      raf.current = requestAnimationFrame(tick);
    },
    [durationUs, speed],
  );

  useEffect(() => {
    if (!playing) return;
    last.current = null;
    raf.current = requestAnimationFrame(tick);
    return () => {
      if (raf.current !== null) cancelAnimationFrame(raf.current);
    };
  }, [playing, tick]);

  const seek = useCallback(
    (us: number) => {
      const v = Math.max(0, Math.min(durationUs, us));
      tRef.current = v;
      setT(v);
    },
    [durationUs],
  );

  /** Attach to the stage element: pause the clock while it is off-screen. */
  const observe = useCallback((el: Element | null) => {
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(([e]) => (visible.current = e?.isIntersecting ?? true));
    io.observe(el);
  }, []);

  return {
    t,
    playing,
    play: () => {
      if (tRef.current >= durationUs) seek(0);
      setPlaying(true);
    },
    pause: () => setPlaying(false),
    seek,
    speed,
    setSpeed,
    observe,
    setOnEnd: (fn: (() => void) | null) => (onEnd.current = fn),
  };
}
