import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { simulate } from "@sdq/sim-engine";
import { parseScenarioYaml, toSimConfig } from "../src/index.js";

const lbKill = readFileSync(resolve(import.meta.dirname, "../../../content/scenarios/lb-kill.yaml"), "utf8");

describe("scenario schema", () => {
  it("parses durations into microseconds", () => {
    const s = parseScenarioYaml(lbKill);
    expect(s.duration).toBe(45_000_000);
    expect(s.events[0]!.at).toBe(20_000_000);
  });

  it("rejects edges that name unknown nodes, with a readable path", () => {
    const bad = lbKill.replace("- [lb, s2]", "- [lb, s9]");
    expect(() => parseScenarioYaml(bad, "bad.yaml")).toThrow(/edges\.1: Edge lb -> s9 names an unknown node/);
  });

  it("catches unquoted commas in flow-style YAML (unknown keys)", () => {
    const bad = lbKill.replace('text: "Nothing much. Server 1 takes over and latency stays the same."', "text: Nothing much, really");
    expect(() => parseScenarioYaml(bad)).toThrow(/Unrecognized key/);
  });

  it("requires a 'what this model ignores' note", () => {
    const bad = lbKill.replace(/ignores:[\s\S]*?(?=\nnarrate:)/, "");
    expect(() => parseScenarioYaml(bad)).toThrow(/ignores/);
  });

  it("the lb-kill lesson behaves as its explanation claims", () => {
    const r = simulate(toSimConfig(parseScenarioYaml(lbKill)));
    const w = r.windows;
    const healthyP99 = Math.max(...w.slice(2, 19).map((x) => x.p99_us ?? 0));
    const lateP99 = Math.max(...w.slice(30, 44).map((x) => x.p99_us ?? 0));
    expect(healthyP99).toBeLessThan(300_000);
    expect(w[20]!.errors + w[21]!.errors).toBeGreaterThan(50); // dead server still getting traffic
    expect(lateP99).toBeGreaterThan(400_000); // server 1 overloaded; bounded queue caps the wait
    expect(w.slice(30, 44).some((x) => x.errors > 0)).toBe(true); // queue full, rejections
  });
});
