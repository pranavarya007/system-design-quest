## What this changes

## Type
- [ ] Fix
- [ ] New or changed scenario
- [ ] New or changed lesson
- [ ] Component
- [ ] Engine
- [ ] Other

## Checklist
- [ ] `pnpm test` and `pnpm validate:content` pass
- [ ] Scenarios include an `ignores:` note, and any `predict.explain` matches what the run shows
- [ ] New facts link to a source
- [ ] Commits are signed off (`git commit -s`)
