import { markSynced, unsynced } from "@sdq/game";

const url = import.meta.env.PUBLIC_SUPABASE_URL as string | undefined;
const key = import.meta.env.PUBLIC_SUPABASE_ANON_KEY as string | undefined;
export const syncEnabled = Boolean(url && key);

type Client = import("@supabase/supabase-js").SupabaseClient;
let clientPromise: Promise<Client> | null = null;

/** Supabase is loaded only when sync is configured and used, so guests never download it. */
export function getClient(): Promise<Client> | null {
  if (!syncEnabled) return null;
  clientPromise ??= import("@supabase/supabase-js").then(({ createClient }) => createClient(url!, key!));
  return clientPromise;
}

export async function signInWithGitHub(): Promise<void> {
  const c = await getClient();
  await c?.auth.signInWithOAuth({ provider: "github", options: { redirectTo: window.location.href } });
}

export async function signOut(): Promise<void> {
  const c = await getClient();
  await c?.auth.signOut();
}

/**
 * Upload unsynced events in one batch. The database function ignores ids it has seen,
 * so this is safe to retry, and it sets XP itself: the client never sends XP amounts.
 */
export async function syncNow(): Promise<number> {
  const c = await getClient();
  if (!c) return 0;
  const { data } = await c.auth.getSession();
  if (!data.session) return 0;
  const batch = await unsynced();
  if (batch.length === 0) return 0;
  const { error } = await c.rpc("ingest_events", {
    events: batch.map(({ id, type, ref, payload, created_at }) => ({ id, type, ref, payload: payload ?? {}, created_at: new Date(created_at).toISOString() })),
  });
  if (error) throw error;
  await markSynced(batch.map((e) => e.id));
  return batch.length;
}
